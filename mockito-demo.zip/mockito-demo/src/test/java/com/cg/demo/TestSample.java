package com.cg.demo;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.internal.WhiteboxImpl;

import com.cg.mockdemo.Sample;
import com.cg.mockdemo.UserRepo;

import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

@RunWith(PowerMockRunner.class)  
@PrepareForTest({Sample.class,UserRepo.class})
public class TestSample {
	
	
	
	@Mock
	Sample s;
	//question 4 using mockito
	

	
	@Test
	public void shouldGetmethod5()
	
	{
		
		when(s.method5()).thenReturn(true);

        // use mock in test....
        s.method5();
		
	}
	
	
	//question 5 using mockito 
	@Test
	public void testvoidmethod() {
		UserRepo mockedUserRepository=mock(UserRepo.class);
		

		
	   doNothing().when(mockedUserRepository).updateName(1L,"void mock test");

	   s.updateName(1L,"void mock test");
		
	  
	   
	}
	
	 
      //question 2
	  
	   @Test
	    public void testprivatemethod() {
	        PowerMockito.mockStatic(UserRepo.class);
	        Mockito.when(UserRepo.getuid()).thenReturn("abcdefgh");
	        
	        s.initialize();
	        
	        
	        
	    } 
	   
	   
	  //question 1 
	    @Test
	    public void testprivatemethodtwo() throws Exception {
	       
	    	PowerMockito.mockStatic(UserRepo.class);
	        List<Integer> list=new ArrayList<Integer>();
	        list.add(5);
	        
	        Mockito.when(UserRepo.add(5)).thenReturn(list);
	        
	        Sample sample=new Sample();
	        List<Integer> result= WhiteboxImpl.invokeMethod(sample, "addnumber",5);
	        // Assert the mocked result is returned from method call
	        Assert.assertEquals(result,list);
	        System.out.println(result);
	    }
	   
	    
	    
	    //question 3
	    
	    @Test
	    public void teststatic() {
	        PowerMockito.mockStatic(Sample.class);
	        
	        String result="capgemini";
	        Mockito.when(Sample.staticMethod(anyString())).thenReturn(result);
	        String output=Sample.staticMethod(result);
	        Assert.assertEquals(output,result);
	        
	        
	        
	    } 

}

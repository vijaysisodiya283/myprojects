package com.cg.mockdemo;

import java.util.ArrayList;
import java.util.List;

public class UserRepo {
	
	static List<Integer> list ;
	
	public UserRepo() {
	list = new ArrayList<Integer>(5); 
	}
	
	public void updateName(Long id, String name)
	{
		System.out.println("updated....");
	}

	public static String getuid() {
		// TODO Auto-generated method stub
		return "abcdefgh";
	}

	public static List<Integer> add(int number) {
		// TODO Auto-generated method stub
		list.add(number);
		return list
				;
	}

}

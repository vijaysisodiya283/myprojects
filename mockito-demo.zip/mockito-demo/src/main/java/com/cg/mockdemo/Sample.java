package com.cg.mockdemo;

import java.util.ArrayList;
import java.util.List;

public class Sample {
	
	private String id;
	UserRepo userRepository;
	
	public Sample()
	{
	 userRepository=new UserRepo();
		
	}
	
	
	public boolean method5()
	{
		System.out.println("checking method 5");
		return true;
	}
	
	
	 public static String staticMethod(String call) {  
	        return call;  
	    } 
	 
	 
	 public void updateName(Long id, String name){
	      userRepository.updateName(id, name);
	   }
	 
	 
		private void generateId()
		{
			id=UserRepo.getuid();
			System.out.println(id);
		}
		
		
		private List<Integer> addnumber(int number)
		{
			return UserRepo.add(number);
		}
		
		
		public void initialize() {
			
			generateId();
		}
		
		public String getid()
		{
			return id;
		}
}

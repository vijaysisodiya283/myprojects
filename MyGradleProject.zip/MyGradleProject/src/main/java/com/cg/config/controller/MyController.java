package com.cg.config.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.config.model.Employee;




@Controller
public class MyController {
	@RequestMapping(value = "/showform", method = RequestMethod.GET)
    public ModelAndView showForm(@ModelAttribute("emp")Employee employee) {
        return new ModelAndView("hello");
    }
 
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String submit( @ModelAttribute("emp")Employee employee, Model model) {
    	//model.addAttribute("emp",new Employee());
        
        model.addAttribute("id", employee.getId());
        model.addAttribute("name", employee.getName());
        model.addAttribute("salary", employee.getSalary());
        model.addAttribute("designation", employee.getDesignation());
        model.addAttribute("email",employee.getEmail());
        return "viewmap";
    }
}
	
	
	

